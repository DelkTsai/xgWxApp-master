//index.js
var util = require('../../utils/util.js');
//获取应用实例
var app = getApp()
Page({
  data: {
    currentTab: 0,
    tookenSession: "",
    imgUrls: [],//轮播图数组
    indicatorDots: true,//是否会出现焦点
    autoplay: true,//是否自动播放
    interval: 5000,//自动播放间隔时间
    duration: 1000,//滑动动画时间
    hengId: "",//横拉时商品id
    hengName: "",//横拉的商品名称
    hengImg: "",//横拉的商品图片
    shoeList: [],//商品列表
    shopLastId: "",//商城的lastid
    shopSearchValue: "",//商城搜索关键字
    windowWidth:"",//屏幕宽度
    buttonS:"",//筛选按钮样式
    shuzu: [],
    ziXunList:[],//潮流资讯列表
    ziXunLastId:""//潮流资讯lastId
    ,dingZhiList:[]//球鞋定制列表
    ,tabPageHeight:0
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    var that = this
    // 获取首页商城数据
    wx.getStorage({
      key: 'token',
      success: function (res) {
        that.setData({
          tokenSession: res.data
        });
        if (that.data.currentTab == 0) {
          var token = res.data;
          var sendFirstPage = {
            "tokenSession": token
          }
          util.getAjax("home/", sendFirstPage, that.shopCallBack);
          var sendFirstPageShoe = {
            "tokenSession": that.data.tokenSession,
            "lastId": "",
            "searchValue": ""
          }
          util.getAjax("home/mall", sendFirstPageShoe, that.firstPageShoeCallBack);
        }
      
        util.getAjax("home/info","", that.ziXunRefreshCallback);
        util.getAjax("home/cases", "", that.dingZhiRefreshCallback);

      }
    });
    //获取屏幕信息
    wx.getSystemInfo({
      success: function (res) {
        // console.log(res.model)
        // console.log(res.pixelRatio)
        console.log(res.windowWidth)
        // console.log(res.windowHeight)
        // console.log(res.language)
        // console.log(res.version)
        that.setData({
          windowWidth: res.windowWidth
          ,tabPageHeight : res.windowHeight
        });
      }
    });
    wx.setNavigationBarTitle({
      title: '首页',
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var sendButoomData;
    if (that.data.currentTab == 0) {
      //商场商品
      sendButoomData = {
        "tokenSession": that.data.tokenSession,
        "lastId": that.data.shopLastId,
        "searchValue": that.data.shopSearchValue
      }
      util.getAjax("home/mall", sendButoomData, that.firstPageShoeCallBack);
    }
    else if (that.data.currentTab == 1) {
      //球鞋定制
    }
    else if (that.data.currentTab == 2) {
      //潮流资讯
    }
  },
  //滑动切换
  swiperTab: function (e) {
    var that = this;
    that.setData({
      currentTba: e.detail.current
    });
  },
  //点击切换
  clickTab: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  //商城获取数据之后的回调
  shopCallBack: function (json) {
    var that = this;
    console.log(json);
    that.setData({
      imgUrls: json.data.slide,
      hengId: json.data.weekGoods.goodsId,
      hengName: json.data.weekGoods.goodsName,
      hengImg: json.data.weekGoods.goodsImg
    });
    // 设置筛选按钮位置
    
    wx.getSystemInfo({
      success: function (res) {
        var wi = res.windowWidth;
        var le = (wi-94)/2
        that.setData({
          buttonS:le
        })
        
      }
    });
  },
  // 转跳到商品详情
  jumpCollection: function (event) {
    var goodsId = event.currentTarget.dataset.goodsId
    var dataType = event.currentTarget.dataset.type;
    wx.navigateTo({
      url: '../personal/collectionDetail?goodsId=' + goodsId + "&type=" + dataType
    })
  },
  // 商城没有搜索第一页返回页面
  firstPageShoeCallBack: function (json) {
    var that = this;
    // that.data.shuzu = [];
    if (json.ret == true) {
      for (var i = 0; i < json.data.length; i++) {
        if (i == json.data.length - 1) {
          var lastid = json.data[i].goodsId
          that.setData({
            shopLastId: lastid
          })
        }
        that.data.shuzu.push(json.data[i]);
      }
      that.setData({
        shoeList: that.data.shuzu
      });
    }
  }
  //潮流资讯 刷新回调
  ,ziXunRefreshCallback:function(json){
    this.setData({
      ziXunList: json.data
    })  ;
  }
  //潮流资讯 加载回调
  , ziXunLoadMoreCallback: function (json) {
    if(json.data!=null && json.data.length==0){
      wx.showToast({
        title: '已经到底了',
      })
      return;
    }
  
    var orgList = this.data.ziXunList;
    orgList.push(json.data);
    this.setData({
      ziXunList: orgList
    });
  }
  //资讯 上拉加载
  , ziXunLoadMore: function (event) {
    var _lastId = this.data.ziXunList[this.data.ziXunList.length - 1].infoId;
    var par = {
      lastId: _lastId
    };
    util.getAjax("home/info", par,this.ziXunLoadMoreCallback);
  }
  //球鞋定制 刷新回调
  ,dingZhiRefreshCallback:function(json){
    this.setData({
      dingZhiList: json.data
    });
  }
  //球鞋定制 加载回调
  , dingZhiLoarMoreCallback: function (json) {
    console.log(json);
    if (json.data != null && json.data.length == 0) {
      wx.showToast({
        title: '已经到底了',
      })
      return;
    }

    var orgList = this.data.dingZhiList;
    orgList.push(json.data);
    this.setData({
      dingZhiList: orgList
    });
  }
  //球鞋定制 上拉加载
  , dingZhiLoadMore: function (evenr) {
    console.log(this.data.dingZhiList);
    var lastKey="";
    for (var keyname in this.data.dingZhiList) {
      lastKey = keyname;
    }
    var lastGroup = this.data.dingZhiList[lastKey];
    var _caseId = lastGroup[lastGroup.length-1].caseId;
    var par = {
      lastId: _caseId
    };

    console.log(par);
    util.getAjax("home/cases", par, this.dingZhiLoarMoreCallback);

  }
})
